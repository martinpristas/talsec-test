//
//  TalsecRuntime.h
//  Talsec
//
//  Created by Jakub Mejtský on 15/12/2018.
//  Copyright © 2018 AHEAD iTec, s.r.o. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TalsecRuntime_iOS.
FOUNDATION_EXPORT double TalsecRuntime_iOSVersionNumber;

//! Project version string for TalsecRuntime.
FOUNDATION_EXPORT const unsigned char TalsecRuntime_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Talsec/PublicHeader.h>

#define __warning__(x)

#import "stdcheaders.h"
#import "mprintf.h"
#import "curl.h"
