//
//  CryptoBridgingHeader.h
//  Talsec
//
//  Created by Jakub Mejtský on 05/08/2019.
//  Copyright © 2019 AHEAD iTec, s.r.o. All rights reserved.
//

#ifndef Crypto_h
#define Crypto_h

#import <CommonCrypto/CommonCrypto.h>

#endif /* Crypto_h */
